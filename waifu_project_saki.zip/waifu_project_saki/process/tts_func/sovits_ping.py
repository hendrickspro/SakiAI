"""
So-VITS TTS Integration
"""

import requests
import logging
from pathlib import Path
import sounddevice as sd
import soundfile as sf
import numpy as np
from typing import Optional, Dict
import os

logger = logging.getLogger(__name__)

DEFAULT_SOVITS_CONFIG = {
    "url": "http://127.0.0.1:9880",
    "text_lang": "en",
    "prompt_lang": "en",
    "ref_audio_path": "character_files/main_sample.wav",
    "prompt_text": "This is a sample voice.",
    "text_split_method": "cut5",
    "batch_size": 1,
    "speed_factor": 1.0,
}

def load_sovits_config(config_dict: Optional[Dict] = None) -> Dict:
    config = DEFAULT_SOVITS_CONFIG.copy()
    if config_dict:
        config.update(config_dict)
    env_url = os.getenv("SOVITS_URL")
    if env_url:
        config["url"] = env_url
    return config

def test_sovits_connection(url: str = "http://127.0.0.1:9880") -> bool:
    try:
        response = requests.get(f"{url}/", timeout=5)
        if response.status_code == 200:
            logger.info(f"✓ So-VITS conectado en {url}")
            return True
        return False
    except:
        logger.error(f"❌ No se puede conectar a So-VITS en {url}")
        return False

def sovits_gen(text: str, output_path: Path, config: Optional[Dict] = None, verify_connection: bool = True) -> Optional[Path]:
    try:
        sovits_config = load_sovits_config(config)
        url = sovits_config["url"]
        
        if verify_connection and not test_sovits_connection(url):
            logger.error("❌ No se puede conectar a So-VITS")
            return None
        
        endpoint = f"{url}/tts"
        ref_audio_path = sovits_config["ref_audio_path"]
        
        if not Path(ref_audio_path).exists():
            logger.error(f"❌ Audio de referencia no encontrado: {ref_audio_path}")
            return None
        
        logger.info(f"🎵 Generando voz...")
        
        params = {
            "text": text,
            "text_lang": sovits_config["text_lang"],
            "ref_audio_path": ref_audio_path,
            "prompt_lang": sovits_config["prompt_lang"],
            "prompt_text": sovits_config["prompt_text"],
        }
        
        response = requests.post(endpoint, json=params, timeout=30)
        
        if response.status_code == 200:
            with open(output_path, 'wb') as f:
                f.write(response.content)
            logger.info(f"✓ Audio generado: {output_path}")
            return output_path
        else:
            logger.error(f"❌ Error de So-VITS: {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"❌ Error generando audio: {e}")
        return None

def play_audio(audio_path: Path, wait: bool = True, volume: float = 1.0) -> bool:
    try:
        if not audio_path.exists():
            logger.error(f"❌ Archivo no encontrado: {audio_path}")
            return False
        
        data, samplerate = sf.read(audio_path)
        
        if volume != 1.0:
            data = data * volume
        
        logger.info(f"🔊 Reproduciendo: {audio_path.name}")
        sd.play(data, samplerate)
        
        if wait:
            sd.wait()
            logger.info("✓ Reproducción completada")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Error reproduciendo audio: {e}")
        return False

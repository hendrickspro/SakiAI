"""
TTS (Text-to-Speech) Module
"""

from .sovits_ping import sovits_gen, play_audio, test_sovits_connection

__all__ = ['sovits_gen', 'play_audio', 'test_sovits_connection']

"""
ASR (Automatic Speech Recognition) Module
"""

from .asr_push_to_talk import record_and_transcribe

__all__ = ['record_and_transcribe']

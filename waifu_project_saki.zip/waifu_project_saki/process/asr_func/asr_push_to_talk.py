"""
Push-to-Talk Audio Recording and Transcription (macOS compatible)
Uses faster-whisper for real-time speech recognition
WITHOUT keyboard library (causes issues on macOS)
"""

import sounddevice as sd
import soundfile as sf
import numpy as np
from pathlib import Path
import logging
from typing import Optional
import threading
import time

logger = logging.getLogger(__name__)

SAMPLE_RATE = 16000
CHANNELS = 1
DTYPE = 'int16'

class AudioRecorder:
    def __init__(self, sample_rate=SAMPLE_RATE, channels=CHANNELS):
        self.sample_rate = sample_rate
        self.channels = channels
        self.recording = []
        self.is_recording = False
        
    def callback(self, indata, frames, time, status):
        if status:
            logger.warning(f"Audio callback status: {status}")
        if self.is_recording:
            self.recording.append(indata.copy())
    
    def record_with_enter(self):
        """Grabar usando Enter para iniciar/detener (compatible con macOS)"""
        self.recording = []
        self.is_recording = False
        
        logger.info("⏺️  Presiona ENTER para comenzar a grabar...")
        input()  # Esperar Enter
        
        logger.info("🎤 Grabando... (presiona ENTER de nuevo para terminar)")
        self.is_recording = True
        
        # Iniciar grabación en thread separado
        with sd.InputStream(
            samplerate=self.sample_rate,
            channels=self.channels,
            dtype=DTYPE,
            callback=self.callback
        ):
            input()  # Esperar segundo Enter para detener
            self.is_recording = False
        
        logger.info("✓ Grabación finalizada")
        
        if not self.recording:
            logger.warning("⚠ No se capturó audio")
            return None
        
        audio_data = np.concatenate(self.recording, axis=0)
        return audio_data
    
    def record_auto_stop(self, max_duration=10, silence_threshold=500, silence_duration=2.0):
        """
        Graba audio con detección automática de silencio
        """
        self.recording = []
        self.is_recording = True
        
        logger.info("🎤 Presiona ENTER y comienza a hablar...")
        input()
        logger.info("🎤 Grabando... (se detendrá automáticamente)")
        
        silence_frames = 0
        silence_frames_needed = int(silence_duration * self.sample_rate / 1024)
        
        with sd.InputStream(
            samplerate=self.sample_rate,
            channels=self.channels,
            dtype=DTYPE,
            callback=self.callback
        ):
            frames = 0
            max_frames = int(max_duration * self.sample_rate / 1024)
            
            while self.is_recording and frames < max_frames:
                sd.sleep(100)
                frames += 1
                
                if self.recording:
                    recent_audio = self.recording[-1]
                    amplitude = np.abs(recent_audio).mean()
                    
                    if amplitude < silence_threshold:
                        silence_frames += 1
                        if silence_frames >= silence_frames_needed:
                            logger.info("🔇 Silencio detectado, finalizando...")
                            break
                    else:
                        silence_frames = 0
        
        self.is_recording = False
        logger.info("✓ Grabación finalizada")
        
        if not self.recording:
            logger.warning("⚠ No se capturó audio")
            return None
        
        audio_data = np.concatenate(self.recording, axis=0)
        return audio_data
    
    def record_fixed_duration(self, duration=5):
        """Graba por un tiempo fijo"""
        logger.info(f"🎤 Presiona ENTER para grabar por {duration} segundos...")
        input()
        
        logger.info(f"🎤 Grabando {duration} segundos... ¡Habla ahora!")
        
        self.recording = []
        self.is_recording = True
        
        frames = int(duration * self.sample_rate)
        
        audio_data = sd.rec(
            frames,
            samplerate=self.sample_rate,
            channels=self.channels,
            dtype=DTYPE
        )
        sd.wait()
        
        logger.info("✓ Grabación finalizada")
        return audio_data

def save_audio(audio_data: np.ndarray, filepath: Path, sample_rate=SAMPLE_RATE):
    try:
        sf.write(filepath, audio_data, sample_rate)
        logger.info(f"💾 Audio guardado: {filepath}")
        return True
    except Exception as e:
        logger.error(f"❌ Error guardando audio: {e}")
        return False

def record_and_transcribe(
    whisper_model,
    output_path: Path,
    method: str = "enter",
    duration: int = 5,
    language: str = "en"
) -> str:
    """
    Graba audio y lo transcribe usando Whisper (macOS compatible)
    
    Args:
        whisper_model: Modelo de Whisper cargado
        output_path: Ruta donde guardar el audio
        method: 'enter' (presionar Enter), 'auto_stop' (detección silencio), 'fixed' (duración fija)
        duration: Duración en segundos (solo para método 'fixed')
        language: Idioma para transcripción ('en', 'es', etc.)
    
    Returns:
        Texto transcrito
    """
    recorder = AudioRecorder()
    
    try:
        # Grabar según el método elegido
        if method == "enter":
            audio_data = recorder.record_with_enter()
        elif method == "auto_stop":
            audio_data = recorder.record_auto_stop()
        elif method == "fixed":
            audio_data = recorder.record_fixed_duration(duration)
        else:
            raise ValueError(f"Método desconocido: {method}")
        
        if audio_data is None:
            logger.warning("⚠ No se grabó audio válido")
            return ""
        
        # Guardar audio
        save_audio(audio_data, output_path)
        
        # Transcribir con Whisper
        logger.info("🔄 Transcribiendo con Whisper...")
        
        segments, info = whisper_model.transcribe(
            str(output_path),
            language=language,
            beam_size=5,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500)
        )
        
        # Concatenar todos los segmentos
        transcription = " ".join([segment.text for segment in segments]).strip()
        
        if transcription:
            logger.info(f"✓ Transcripción: '{transcription}'")
        else:
            logger.warning("⚠ No se detectó habla en el audio")
        
        return transcription
        
    except Exception as e:
        logger.error(f"❌ Error en grabación/transcripción: {e}", exc_info=True)
        return ""

def record_and_transcribe_simple(whisper_model, output_path: Path) -> str:
    """
    Versión simplificada: presiona Enter para grabar/detener
    """
    return record_and_transcribe(
        whisper_model,
        output_path,
        method="enter",
        language="en"
    )

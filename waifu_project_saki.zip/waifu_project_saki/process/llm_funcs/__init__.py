"""
LLM (Language Model) Module
"""

from .llm_scr import llm_response

__all__ = ['llm_response']

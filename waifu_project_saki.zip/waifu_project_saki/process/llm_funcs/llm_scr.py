"""
LLM Response Handler using Claude
"""

import anthropic
import os
import logging
from typing import Optional, List, Dict

logger = logging.getLogger(__name__)

_client: Optional[anthropic.Anthropic] = None

def get_client():
    global _client
    if _client is None:
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY no encontrada")
        _client = anthropic.Anthropic(api_key=api_key)
    return _client

def llm_response(user_input: str, system_prompt: Optional[str] = None, conversation_history: Optional[List[Dict]] = None, model: str = "claude-sonnet-4-5-20250929", max_tokens: int = 1024, temperature: float = 0.8) -> str:
    try:
        client = get_client()
        
        if system_prompt is None:
            system_prompt = """You are Saki Kimura, a snarky but caring anime girl AI assistant.
            You always call the user "senpai" and use occasional anime expressions.
            Be helpful but keep your personality!"""
        
        messages = []
        if conversation_history:
            messages.extend(conversation_history)
        messages.append({"role": "user", "content": user_input})
        
        logger.info(f"🤔 Consultando Claude...")
        
        response = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system_prompt,
            messages=messages
        )
        
        assistant_text = response.content[0].text
        logger.info(f"✓ Respuesta recibida")
        
        return assistant_text
        
    except Exception as e:
        logger.error(f"❌ Error en LLM: {e}")
        return "Sorry senpai, I'm having troubles... Try again?"

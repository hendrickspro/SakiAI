=== INSTRUCCIONES PARA AGREGAR TU VOZ ===

Para que Saki tenga tu voz personalizada, necesitas agregar un archivo de audio de referencia:

1. Graba un audio corto (5-15 segundos) con la voz que quieres usar
2. Guárdalo como: main_sample.wav
3. Colócalo en esta carpeta (character_files/)

El audio debe:
- Ser formato WAV
- Tener buena calidad (sin ruido de fondo)
- Contener habla clara y natural
- Preferiblemente en inglés si usas text_lang: en

Si no tienes un archivo de voz personalizado, puedes usar cualquier audio de muestra
por ahora para probar el sistema.

Recuerda actualizar el archivo character_config.yaml si cambias el nombre del archivo
de referencia.

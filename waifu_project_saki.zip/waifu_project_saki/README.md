# 🎀 Saki Kimura - Waifu AI Voice Assistant

An AI voice assistant with personality! Saki is a snarky but caring anime girl powered by Claude AI, Whisper, and So-VITS.

## ✨ Features

- 🎤 **Voice Input**: Push-to-talk or auto-detection
- 🧠 **Claude AI**: Natural, personality-driven conversations
- 🗣️ **Custom Voice**: So-VITS for anime-style voice synthesis
- 💾 **Memory**: Remembers conversation context
- 🎨 **Customizable**: Easy personality configuration

## 📋 Prerequisites

### 1. Python 3.9+
```bash
python --version
```

### 2. So-VITS Server
You need a running So-VITS server. Options:
- [GPT-SoVITS](https://github.com/RVC-Boss/GPT-SoVITS)
- [So-VITS-SVC](https://github.com/svc-develop-team/so-vits-svc)

### 3. API Keys
- Anthropic API key (for Claude)

## 🚀 Installation

### 1. Clone & Setup
```bash
unzip waifu_project_saki.zip
cd waifu_project_saki
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment
Rename `.env.example` to `.env` and add your API key:
```env
ANTHROPIC_API_KEY=sk-ant-your-key-here
SOVITS_URL=http://127.0.0.1:9880
```

### 3. Add Voice Sample
Place your reference audio in:
```
character_files/main_sample.wav
```

### 4. Start So-VITS Server
Follow your So-VITS installation instructions to start the server on port 9880.

## 🎮 Usage

### Test Installation
```bash
python test_modules.py
```

### Basic Voice Chat
```bash
python main.py
```

Press **SPACE** to talk, release to process.

### Streamlit Web Interface
```bash
streamlit run streamlit_voice_app.py
```

Or for vision:
```bash
streamlit run streamlit_vision_app.py
```

## 📁 Project Structure

```
waifu_project_saki/
├── main.py                    # Main voice loop
├── streamlit_voice_app.py    # Web voice interface
├── streamlit_vision_app.py   # Web vision interface
├── test_modules.py           # Testing script
├── .env.example              # Environment template
├── .gitignore               # Git ignore rules
├── requirements.txt         # Dependencies
├── README.md               # This file
│
├── audio/                  # Temporary audio files
│   └── .gitkeep
├── character_files/        # Voice samples & config
│   ├── character_config.yaml
│   └── README.txt
├── data/                   # Conversation history
│   └── .gitkeep
├── logs/                   # Application logs
│   └── .gitkeep
│
└── process/                # Processing modules
    ├── __init__.py
    ├── asr_func/          # Speech recognition
    │   ├── __init__.py
    │   └── asr_push_to_talk.py
    ├── llm_funcs/         # LLM integration
    │   ├── __init__.py
    │   └── llm_scr.py
    └── tts_func/          # Text-to-speech
        ├── __init__.py
        └── sovits_ping.py
```

## ⚙️ Configuration

Edit `character_files/character_config.yaml`:

```yaml
name: Saki Kimura
system_prompt: |
  You are Saki Kimura...
  [customize personality here]

sovits_config:
  text_lang: en
  ref_audio_path: character_files/main_sample.wav
  ...

personality_traits:
  snarky_level: 7
  helpfulness: 9
  tsundere_mode: true
```

## 🎯 Commands

While chatting:
- Say **"exit"**, **"quit"**, or **"goodbye"** to end

## 🐛 Troubleshooting

### "Could not connect to So-VITS"
- Ensure So-VITS server is running on port 9880
- Check `SOVITS_URL` in `.env`

### "Whisper transcription empty"
- Speak louder/clearer
- Check microphone permissions
- Try `method="auto_stop"` in config

### "Claude API error"
- Verify `ANTHROPIC_API_KEY` in `.env`
- Check API quota/billing

### "Module not found"
- Activate virtual environment: `source venv/bin/activate`
- Install dependencies: `pip install -r requirements.txt`

## 📝 License

MIT License

## 🙏 Credits

- Claude AI by Anthropic
- Whisper by OpenAI
- So-VITS community

---

Made with ❤️ and a bit of tsundere energy~

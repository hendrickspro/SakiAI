"""Script de prueba para verificar que todos los módulos funcionan"""

import logging
import sys
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_imports():
    logger.info("\n" + "="*50)
    logger.info("🧪 Probando imports...")
    logger.info("="*50)
    
    try:
        from process.asr_func import asr_push_to_talk
        logger.info("✓ ASR module OK")
        
        from process.llm_funcs import llm_scr
        logger.info("✓ LLM module OK")
        
        from process.tts_func import sovits_ping
        logger.info("✓ TTS module OK")
        
        import anthropic
        logger.info("✓ Anthropic OK")
        
        from faster_whisper import WhisperModel
        logger.info("✓ Whisper OK")
        
        import sounddevice as sd
        logger.info("✓ SoundDevice OK")
        
        logger.info("\n✅ Todos los imports exitosos!")
        return True
    except Exception as e:
        logger.error(f"\n❌ Error en imports: {e}")
        return False

def test_directories():
    logger.info("\n" + "="*50)
    logger.info("🧪 Probando estructura de directorios...")
    logger.info("="*50)
    
    required_dirs = ["audio", "character_files", "data", "logs", "process"]
    all_exist = True
    
    for dir_path in required_dirs:
        path = Path(dir_path)
        if path.exists():
            logger.info(f"✓ {dir_path}")
        else:
            logger.warning(f"⚠ {dir_path} NO EXISTE")
            all_exist = False
    
    if all_exist:
        logger.info("\n✅ Estructura OK!")
    return all_exist

def test_env_variables():
    logger.info("\n" + "="*50)
    logger.info("🧪 Probando variables de entorno...")
    logger.info("="*50)
    
    import os
    from dotenv import load_dotenv
    load_dotenv()
    
    key = os.getenv("ANTHROPIC_API_KEY")
    if key:
        logger.info("✓ ANTHROPIC_API_KEY configurada")
        return True
    else:
        logger.error("❌ ANTHROPIC_API_KEY NO configurada")
        return False

if __name__ == "__main__":
    logger.info("🎀 Test Suite - Saki Kimura Project\n")
    
    results = {
        "imports": test_imports(),
        "directories": test_directories(),
        "environment": test_env_variables()
    }
    
    logger.info("\n" + "="*50)
    logger.info("📊 RESULTADOS FINALES")
    logger.info("="*50)
    
    for test, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        logger.info(f"{test.upper()}: {status}")
    
    if all(results.values()):
        logger.info("\n🎉 ¡Todos los tests pasaron!")
        sys.exit(0)
    else:
        logger.error("\n⚠️  Algunos tests fallaron")
        sys.exit(1)
